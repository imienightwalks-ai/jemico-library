import React, { useEffect } from 'react'
import { X, ZoomIn } from 'lucide-react'

export default function Lightbox({ src, alt, onClose }) {
  useEffect(() => {
    const handler = e => { if (e.key === 'Escape') onClose() }
    window.addEventListener('keydown', handler)
    document.body.style.overflow = 'hidden'
    return () => {
      window.removeEventListener('keydown', handler)
      document.body.style.overflow = ''
    }
  }, [onClose])

  return (
    <div
      className="fixed inset-0 z-[100] flex items-center justify-center p-4 animate-fade-in"
      onClick={e => { if (e.target === e.currentTarget) onClose() }}
    >
      <div className="absolute inset-0 bg-ink-900/90 backdrop-blur-md" onClick={onClose} />
      <div className="relative z-10 max-w-4xl w-full animate-scale-in">
        <button
          onClick={onClose}
          className="absolute -top-10 right-0 text-cream-300 hover:text-white transition-colors p-2"
        >
          <X size={22} />
        </button>
        <img
          src={src}
          alt={alt || 'Quote image'}
          className="w-full h-auto max-h-[85vh] object-contain rounded-2xl shadow-2xl"
        />
      </div>
    </div>
  )
}

export function ImageQuoteCard({ src, alt, onClick }) {
  return (
    <div
      className="relative group cursor-zoom-in overflow-hidden rounded-xl border border-cream-300/60 dark:border-ink-600/40"
      onClick={onClick}
    >
      <img
        src={src}
        alt={alt || 'Quote'}
        className="w-full h-auto object-cover transition-transform duration-500 group-hover:scale-[1.02]"
        style={{ maxHeight: 320 }}
      />
      <div className="absolute inset-0 bg-ink-900/0 group-hover:bg-ink-900/20 transition-all duration-300 flex items-center justify-center">
        <ZoomIn className="text-white opacity-0 group-hover:opacity-100 transition-all duration-300 drop-shadow-lg" size={28} />
      </div>
    </div>
  )
}
