import React, { useState } from 'react'
import Modal from './Modal'
import { Type, Image as ImageIcon, Upload, X } from 'lucide-react'
import { fileToDataUrl } from '../utils/helpers'

export default function AddQuoteModal({ open, onClose, onSave }) {
  const [type, setType] = useState('text')
  const [text, setText] = useState('')
  const [page, setPage] = useState('')
  const [tags, setTags] = useState('')
  const [imageData, setImageData] = useState(null)

  function reset() {
    setText(''); setPage(''); setTags(''); setImageData(''); setType('text')
  }

  function handleClose() { reset(); onClose() }

  async function handleImageFile(e) {
    const file = e.target.files?.[0]
    if (!file) return
    const data = await fileToDataUrl(file)
    setImageData(data)
  }

  function handleSave() {
    if (type === 'text' && !text.trim()) return
    if (type === 'image' && !imageData) return
    const tagList = tags.split(',').map(t => t.trim()).filter(Boolean)
    onSave({ type, text: text.trim(), page: page.trim(), tags: tagList, imageData })
    reset()
    onClose()
  }

  return (
    <Modal open={open} onClose={handleClose} title="Add Quote" size="lg">
      {/* Type toggle */}
      <div className="flex gap-2 mb-5 p-1 bg-cream-100 dark:bg-ink-800 rounded-xl">
        {[
          { key: 'text', icon: Type, label: 'Text Quote' },
          { key: 'image', icon: ImageIcon, label: 'Image Quote' },
        ].map(({ key, icon: Icon, label }) => (
          <button
            key={key}
            onClick={() => setType(key)}
            className={`flex-1 flex items-center justify-center gap-2 py-2 text-sm rounded-lg transition-all font-medium ${
              type === key
                ? 'bg-white dark:bg-ink-700 text-ink-800 dark:text-cream-100 shadow-sm'
                : 'text-ink-400 dark:text-ink-500 hover:text-ink-600 dark:hover:text-ink-300'
            }`}
          >
            <Icon size={14} /> {label}
          </button>
        ))}
      </div>

      <div className="space-y-4">
        {type === 'text' ? (
          <div>
            <label className="block text-xs font-medium text-ink-500 dark:text-ink-400 uppercase tracking-wide mb-1.5">
              Quote *
            </label>
            <textarea
              className="input-field resize-none font-serif italic text-base"
              rows={4}
              placeholder="Enter the quote here…"
              value={text}
              onChange={e => setText(e.target.value)}
              autoFocus
            />
          </div>
        ) : (
          <div>
            <label className="block text-xs font-medium text-ink-500 dark:text-ink-400 uppercase tracking-wide mb-1.5">
              Quote Image *
            </label>
            {imageData ? (
              <div className="relative rounded-xl overflow-hidden border border-cream-300 dark:border-ink-600">
                <img src={imageData} alt="Quote" className="w-full h-auto max-h-60 object-contain bg-cream-50 dark:bg-ink-900" />
                <button
                  onClick={() => setImageData(null)}
                  className="absolute top-2 right-2 w-7 h-7 bg-ink-900/70 text-white rounded-full flex items-center justify-center hover:bg-ink-900"
                >
                  <X size={13} />
                </button>
              </div>
            ) : (
              <label className="flex flex-col items-center justify-center w-full h-36 border border-dashed border-cream-400 dark:border-ink-600 rounded-xl cursor-pointer hover:border-ink-400 dark:hover:border-ink-400 hover:bg-cream-50 dark:hover:bg-ink-800/50 transition-all group">
                <Upload size={22} className="text-ink-400 group-hover:text-ink-600 dark:group-hover:text-ink-300 mb-2 transition-colors" />
                <span className="text-sm text-ink-400 dark:text-ink-500">Upload quote screenshot</span>
                <span className="text-xs text-ink-300 dark:text-ink-600 mt-0.5">JPG, PNG, WEBP</span>
                <input type="file" accept="image/*" className="hidden" onChange={handleImageFile} />
              </label>
            )}
          </div>
        )}

        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="block text-xs font-medium text-ink-500 dark:text-ink-400 uppercase tracking-wide mb-1.5">
              Page (optional)
            </label>
            <input
              className="input-field"
              placeholder="e.g. 142"
              value={page}
              onChange={e => setPage(e.target.value)}
            />
          </div>
          <div>
            <label className="block text-xs font-medium text-ink-500 dark:text-ink-400 uppercase tracking-wide mb-1.5">
              Tags (optional)
            </label>
            <input
              className="input-field"
              placeholder="love, life, hope"
              value={tags}
              onChange={e => setTags(e.target.value)}
            />
          </div>
        </div>

        <div className="flex gap-2 pt-1">
          <button
            onClick={handleSave}
            disabled={(type === 'text' && !text.trim()) || (type === 'image' && !imageData)}
            className="btn-primary flex-1 disabled:opacity-40"
          >
            Add Quote
          </button>
          <button onClick={handleClose} className="btn-ghost">Cancel</button>
        </div>
      </div>
    </Modal>
  )
}
