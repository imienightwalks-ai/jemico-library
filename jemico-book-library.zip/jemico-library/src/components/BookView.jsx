import React, { useState, useMemo } from 'react'
import { ArrowLeft, Plus, Heart, Pin, Filter } from 'lucide-react'
import QuoteCard from './QuoteCard'
import AddQuoteModal from './AddQuoteModal'
import Lightbox from './Lightbox'
import { normalizeSearch } from '../utils/helpers'

const FILTERS = [
  { key: 'all', label: 'All' },
  { key: 'pinned', label: 'Pinned' },
  { key: 'favorites', label: 'Favorites' },
  { key: 'text', label: 'Text' },
  { key: 'image', label: 'Images' },
]

export default function BookView({ book, editMode, onBack, onAddQuote, onEditQuote, onDeleteQuote, onFavorite, onPin, searchQuery }) {
  const [addOpen, setAddOpen] = useState(false)
  const [lightboxSrc, setLightboxSrc] = useState(null)
  const [filter, setFilter] = useState('all')
  const [localSearch, setLocalSearch] = useState('')

  const quotes = useMemo(() => {
    let q = [...(book.quotes || [])]

    // Sort: pinned first
    q.sort((a, b) => (b.pinned ? 1 : 0) - (a.pinned ? 1 : 0))

    // Apply filter
    if (filter === 'pinned') q = q.filter(x => x.pinned)
    if (filter === 'favorites') q = q.filter(x => x.favorite)
    if (filter === 'text') q = q.filter(x => x.type === 'text')
    if (filter === 'image') q = q.filter(x => x.type === 'image')

    // Apply search
    const term = normalizeSearch(localSearch || searchQuery)
    if (term) {
      q = q.filter(x =>
        normalizeSearch(x.text).includes(term) ||
        (x.tags || []).some(t => normalizeSearch(t).includes(term))
      )
    }

    return q
  }, [book.quotes, filter, localSearch, searchQuery])

  const allTags = useMemo(() => {
    const set = new Set()
    ;(book.quotes || []).forEach(q => (q.tags || []).forEach(t => set.add(t)))
    return [...set]
  }, [book.quotes])

  return (
    <div className="animate-fade-in">
      {/* Back + Header */}
      <div className="flex items-start gap-4 mb-8">
        <button onClick={onBack} className="icon-btn mt-1 flex-shrink-0">
          <ArrowLeft size={18} />
        </button>

        <div className="flex-1 flex items-start gap-4">
          {book.cover && (
            <img
              src={book.cover}
              alt={book.title}
              className="hidden sm:block w-16 h-24 object-cover rounded-lg shadow-md flex-shrink-0"
            />
          )}
          <div>
            <h2 className="font-serif text-2xl sm:text-3xl font-medium text-ink-800 dark:text-cream-100 leading-tight">
              {book.title}
            </h2>
            <p className="text-sm text-ink-400 dark:text-ink-500 mt-1 font-sans">
              {book.quotes?.length || 0} quotes saved
            </p>
            {allTags.length > 0 && (
              <div className="flex flex-wrap gap-1.5 mt-2">
                {allTags.slice(0, 6).map(t => (
                  <span key={t} className="tag-pill cursor-pointer hover:border-ink-400 transition-colors"
                    onClick={() => setLocalSearch(t)}>
                    #{t}
                  </span>
                ))}
              </div>
            )}
          </div>
        </div>

        {editMode && (
          <button
            onClick={() => setAddOpen(true)}
            className="btn-primary flex items-center gap-1.5 flex-shrink-0"
          >
            <Plus size={14} /> Add Quote
          </button>
        )}
      </div>

      {/* Filters */}
      <div className="flex items-center gap-2 mb-6 overflow-x-auto pb-1 -mx-1 px-1">
        {FILTERS.map(f => (
          <button
            key={f.key}
            onClick={() => setFilter(f.key)}
            className={`flex-shrink-0 text-xs font-medium px-3 py-1.5 rounded-full border transition-all
              ${filter === f.key
                ? 'bg-ink-800 dark:bg-cream-200 text-white dark:text-ink-900 border-transparent'
                : 'border-cream-300 dark:border-ink-600 text-ink-500 dark:text-ink-400 hover:border-ink-400 dark:hover:border-ink-500 bg-white/50 dark:bg-ink-800/50'
              }`}
          >
            {f.key === 'favorites' && '♥ '}{f.label}
          </button>
        ))}
      </div>

      {/* Quotes Grid */}
      {quotes.length === 0 ? (
        <div className="text-center py-20">
          <p className="font-serif text-2xl italic text-ink-300 dark:text-ink-600 mb-3">
            {book.quotes?.length === 0 ? '"Every book starts with a single quote…"' : 'No quotes match your filter.'}
          </p>
          {editMode && book.quotes?.length === 0 && (
            <button onClick={() => setAddOpen(true)} className="btn-primary mt-2">
              Add your first quote
            </button>
          )}
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {quotes.map(q => (
            <QuoteCard
              key={q.id}
              quote={q}
              bookTitle={book.title}
              editMode={editMode}
              onEdit={changes => onEditQuote(q.id, changes)}
              onDelete={() => onDeleteQuote(q.id)}
              onFavorite={() => onFavorite(q.id)}
              onPin={() => onPin(q.id)}
              onImageClick={src => setLightboxSrc(src)}
            />
          ))}
        </div>
      )}

      <AddQuoteModal
        open={addOpen}
        onClose={() => setAddOpen(false)}
        onSave={data => onAddQuote(data)}
      />

      {lightboxSrc && (
        <Lightbox src={lightboxSrc} onClose={() => setLightboxSrc(null)} />
      )}
    </div>
  )
}
