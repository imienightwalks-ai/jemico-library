import React, { useState, useMemo } from 'react'
import { Plus, BookOpen } from 'lucide-react'
import { useStore } from './hooks/useStore'
import Header from './components/Header'
import BookCard from './components/BookCard'
import BookView from './components/BookView'
import BookModal from './components/BookModal'
import { normalizeSearch } from './utils/helpers'

export default function App() {
  const {
    books, stats,
    addBook, updateBook, deleteBook,
    addQuote, updateQuote, deleteQuote,
    toggleFavorite, togglePin,
    editMode, setEditMode,
    darkMode, setDarkMode,
  } = useStore()

  const [currentBookId, setCurrentBookId] = useState(null)
  const [bookModalOpen, setBookModalOpen] = useState(false)
  const [editingBook, setEditingBook] = useState(null)
  const [searchQuery, setSearchQuery] = useState('')

  const currentBook = books.find(b => b.id === currentBookId)

  // Filter books by search
  const filteredBooks = useMemo(() => {
    if (!searchQuery.trim()) return books
    const term = normalizeSearch(searchQuery)
    return books.filter(b =>
      normalizeSearch(b.title).includes(term) ||
      (b.quotes || []).some(q => normalizeSearch(q.text).includes(term) ||
        (q.tags || []).some(t => normalizeSearch(t).includes(term)))
    )
  }, [books, searchQuery])

  function handleOpenBook(id) {
    setCurrentBookId(id)
    setSearchQuery('')
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }

  function handleEditBook(book) {
    setEditingBook(book)
    setBookModalOpen(true)
  }

  function handleSaveBook({ title, cover }) {
    if (editingBook) {
      updateBook(editingBook.id, { title, cover })
    } else {
      addBook(title, cover)
    }
    setEditingBook(null)
  }

  function handleDeleteBook(id) {
    if (window.confirm('Delete this book and all its quotes?')) {
      deleteBook(id)
      if (currentBookId === id) setCurrentBookId(null)
    }
  }

  function handleDeleteQuote(quoteId) {
    if (window.confirm('Delete this quote?')) {
      deleteQuote(currentBookId, quoteId)
    }
  }

  return (
    <div className="min-h-screen grain transition-colors duration-300">
      <Header
        darkMode={darkMode}
        setDarkMode={setDarkMode}
        editMode={editMode}
        setEditMode={setEditMode}
        searchQuery={searchQuery}
        setSearchQuery={setSearchQuery}
        stats={stats}
      />

      <main className="max-w-6xl mx-auto px-4 sm:px-6 py-8 sm:py-12">
        {currentBook ? (
          <BookView
            book={currentBook}
            editMode={editMode}
            onBack={() => setCurrentBookId(null)}
            onAddQuote={data => addQuote(currentBook.id, data)}
            onEditQuote={(qId, changes) => updateQuote(currentBook.id, qId, changes)}
            onDeleteQuote={handleDeleteQuote}
            onFavorite={qId => toggleFavorite(currentBook.id, qId)}
            onPin={qId => togglePin(currentBook.id, qId)}
            searchQuery={searchQuery}
          />
        ) : (
          <>
            {/* Hero */}
            <div className="mb-10 sm:mb-14">
              <p className="text-xs text-ink-400 dark:text-ink-500 font-sans uppercase tracking-widest mb-2">Personal Collection</p>
              <h2 className="font-serif text-3xl sm:text-5xl font-light text-ink-800 dark:text-cream-100 leading-tight mb-3">
                Book Quotes<br />
                <em className="text-ink-400 dark:text-ink-500">Library</em>
              </h2>
              <p className="text-sm text-ink-400 dark:text-ink-500 font-sans max-w-sm leading-relaxed">
                A quiet place to collect words that moved you. Every book, every quote — remembered.
              </p>
            </div>

            {/* Stats bar */}
            {books.length > 0 && (
              <div className="flex items-center gap-6 mb-8 pb-6 border-b border-cream-200/80 dark:border-ink-700/60">
                <div>
                  <p className="text-2xl font-serif font-medium text-ink-800 dark:text-cream-100">{stats.totalBooks}</p>
                  <p className="text-xs text-ink-400 dark:text-ink-500 font-sans">Books</p>
                </div>
                <div className="w-px h-8 bg-cream-300 dark:bg-ink-700" />
                <div>
                  <p className="text-2xl font-serif font-medium text-ink-800 dark:text-cream-100">{stats.totalQuotes}</p>
                  <p className="text-xs text-ink-400 dark:text-ink-500 font-sans">Quotes</p>
                </div>
                <div className="w-px h-8 bg-cream-300 dark:bg-ink-700" />
                <div>
                  <p className="text-2xl font-serif font-medium text-gold-500">{stats.totalFavorites}</p>
                  <p className="text-xs text-ink-400 dark:text-ink-500 font-sans">Favorites</p>
                </div>
              </div>
            )}

            {/* Book Grid */}
            {filteredBooks.length === 0 && searchQuery ? (
              <div className="text-center py-16">
                <p className="font-serif text-xl italic text-ink-300 dark:text-ink-600">No results for "{searchQuery}"</p>
              </div>
            ) : books.length === 0 ? (
              <div className="text-center py-20">
                <BookOpen size={40} className="mx-auto text-ink-200 dark:text-ink-700 mb-4" strokeWidth={1} />
                <p className="font-serif text-2xl italic text-ink-300 dark:text-ink-600 mb-2">
                  Your library is empty
                </p>
                <p className="text-sm text-ink-400 dark:text-ink-500 mb-6 font-sans">
                  Add your first book to start collecting quotes.
                </p>
                {editMode && (
                  <button onClick={() => setBookModalOpen(true)} className="btn-primary">
                    Add your first book
                  </button>
                )}
                {!editMode && (
                  <p className="text-xs text-ink-300 dark:text-ink-600 font-sans">Switch to Edit mode to add books.</p>
                )}
              </div>
            ) : (
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-5 sm:gap-6">
                {filteredBooks.map(book => (
                  <BookCard
                    key={book.id}
                    book={book}
                    editMode={editMode}
                    onClick={() => handleOpenBook(book.id)}
                    onEdit={() => handleEditBook(book)}
                    onDelete={() => handleDeleteBook(book.id)}
                  />
                ))}
                {/* Add book tile */}
                {editMode && (
                  <button
                    onClick={() => { setEditingBook(null); setBookModalOpen(true) }}
                    className="flex flex-col items-center justify-center aspect-[3/4] border-2 border-dashed border-cream-300 dark:border-ink-700 rounded-xl text-ink-300 dark:text-ink-600 hover:border-ink-400 dark:hover:border-ink-500 hover:text-ink-400 dark:hover:text-ink-500 transition-all group"
                  >
                    <Plus size={22} className="mb-2 group-hover:scale-110 transition-transform" />
                    <span className="text-xs font-sans font-medium">Add book</span>
                  </button>
                )}
              </div>
            )}
          </>
        )}
      </main>

      {/* Footer */}
      <footer className="text-center py-10 text-xs text-ink-300 dark:text-ink-600 font-sans tracking-wide">
        <span className="font-serif italic text-ink-400 dark:text-ink-500">Created by Jemico</span>
        <span className="mx-2">·</span>
        <span>Book Quotes Library</span>
      </footer>

      <BookModal
        open={bookModalOpen}
        onClose={() => { setBookModalOpen(false); setEditingBook(null) }}
        onSave={handleSaveBook}
        initial={editingBook}
      />
    </div>
  )
}
