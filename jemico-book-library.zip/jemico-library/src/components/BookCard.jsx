import React, { useState } from 'react'
import { BookOpen, MoreVertical, Edit2, Trash2, Quote } from 'lucide-react'

export default function BookCard({ book, onClick, onEdit, onDelete, editMode }) {
  const [menuOpen, setMenuOpen] = useState(false)
  const quoteCount = book.quotes?.length || 0
  const favCount = book.quotes?.filter(q => q.favorite)?.length || 0

  return (
    <div
      className="group relative animate-slide-up cursor-pointer"
      onClick={onClick}
    >
      {/* Cover */}
      <div className="relative overflow-hidden rounded-xl mb-3 aspect-[3/4] shadow-md group-hover:shadow-xl transition-shadow duration-300">
        {book.cover ? (
          <img
            src={book.cover}
            alt={book.title}
            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
          />
        ) : (
          <div className="w-full h-full flex flex-col items-center justify-center bg-gradient-to-br from-cream-200 to-cream-400 dark:from-ink-700 dark:to-ink-800 gap-3">
            <BookOpen size={32} className="text-ink-400 dark:text-ink-500" strokeWidth={1.2} />
            <span className="text-xs text-ink-400 dark:text-ink-500 font-sans font-medium tracking-wide uppercase">No Cover</span>
          </div>
        )}

        {/* Overlay on hover */}
        <div className="absolute inset-0 bg-ink-900/0 group-hover:bg-ink-900/20 transition-all duration-300 rounded-xl" />

        {/* Badges */}
        {favCount > 0 && (
          <div className="absolute top-2 left-2 bg-white/90 dark:bg-ink-800/90 text-gold-500 text-xs font-medium px-2 py-0.5 rounded-full backdrop-blur-sm flex items-center gap-1 shadow-sm">
            ♥ {favCount}
          </div>
        )}

        {/* Action menu */}
        {editMode && (
          <div className="absolute top-2 right-2" onClick={e => e.stopPropagation()}>
            <button
              onClick={() => setMenuOpen(o => !o)}
              className="w-7 h-7 rounded-lg bg-white/90 dark:bg-ink-800/90 backdrop-blur-sm flex items-center justify-center shadow-sm text-ink-600 dark:text-ink-300 hover:bg-white dark:hover:bg-ink-700 transition-all opacity-0 group-hover:opacity-100"
            >
              <MoreVertical size={13} />
            </button>
            {menuOpen && (
              <div className="absolute right-0 top-9 w-36 glass-card shadow-xl py-1 z-20 animate-scale-in">
                <button
                  onClick={() => { setMenuOpen(false); onEdit() }}
                  className="w-full flex items-center gap-2 px-3 py-2 text-sm text-ink-700 dark:text-ink-300 hover:bg-cream-100 dark:hover:bg-ink-700 transition-colors"
                >
                  <Edit2 size={12} /> Edit book
                </button>
                <button
                  onClick={() => { setMenuOpen(false); onDelete() }}
                  className="w-full flex items-center gap-2 px-3 py-2 text-sm text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 transition-colors"
                >
                  <Trash2 size={12} /> Delete
                </button>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Info */}
      <div>
        <h3 className="font-serif text-base font-medium text-ink-800 dark:text-cream-100 leading-snug line-clamp-2 group-hover:text-ink-600 dark:group-hover:text-cream-200 transition-colors">
          {book.title}
        </h3>
        <p className="text-xs text-ink-400 dark:text-ink-500 mt-1 font-sans flex items-center gap-1">
          <Quote size={10} />
          {quoteCount} quote{quoteCount !== 1 ? 's' : ''}
        </p>
      </div>
    </div>
  )
}
