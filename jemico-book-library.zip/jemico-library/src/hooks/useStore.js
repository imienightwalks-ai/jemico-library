import { useState, useEffect, useCallback } from 'react'

const STORAGE_KEY = 'jemico_library_v2'

function uid() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2)
}

function loadData() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY)
    if (raw) return JSON.parse(raw)
  } catch {}
  return { books: [], settings: {} }
}

function saveData(data) {
  try { localStorage.setItem(STORAGE_KEY, JSON.stringify(data)) } catch {}
}

export function useStore() {
  const [data, setData] = useState(loadData)
  const [editMode, setEditMode] = useState(false)
  const [darkMode, setDarkMode] = useState(() => {
    const saved = localStorage.getItem('jemico_dark')
    return saved ? saved === 'true' : window.matchMedia('(prefers-color-scheme: dark)').matches
  })

  // Persist dark mode
  useEffect(() => {
    document.documentElement.classList.toggle('dark', darkMode)
    localStorage.setItem('jemico_dark', String(darkMode))
  }, [darkMode])

  // Persist books data
  useEffect(() => {
    saveData(data)
  }, [data])

  const books = data.books || []

  // ── Books ──────────────────────────────────────────────────────────────
  const addBook = useCallback((title, cover) => {
    const book = { id: uid(), title, cover: cover || null, quotes: [], createdAt: new Date().toISOString() }
    setData(d => ({ ...d, books: [book, ...d.books] }))
    return book.id
  }, [])

  const updateBook = useCallback((id, changes) => {
    setData(d => ({
      ...d,
      books: d.books.map(b => b.id === id ? { ...b, ...changes } : b)
    }))
  }, [])

  const deleteBook = useCallback((id) => {
    setData(d => ({ ...d, books: d.books.filter(b => b.id !== id) }))
  }, [])

  // ── Quotes ─────────────────────────────────────────────────────────────
  const addQuote = useCallback((bookId, quoteData) => {
    const quote = {
      id: uid(),
      type: quoteData.type || 'text', // 'text' | 'image'
      text: quoteData.text || '',
      imageData: quoteData.imageData || null,
      tags: quoteData.tags || [],
      page: quoteData.page || '',
      pinned: false,
      favorite: false,
      createdAt: new Date().toISOString(),
    }
    setData(d => ({
      ...d,
      books: d.books.map(b =>
        b.id === bookId ? { ...b, quotes: [quote, ...b.quotes] } : b
      )
    }))
    return quote.id
  }, [])

  const updateQuote = useCallback((bookId, quoteId, changes) => {
    setData(d => ({
      ...d,
      books: d.books.map(b =>
        b.id === bookId
          ? { ...b, quotes: b.quotes.map(q => q.id === quoteId ? { ...q, ...changes } : q) }
          : b
      )
    }))
  }, [])

  const deleteQuote = useCallback((bookId, quoteId) => {
    setData(d => ({
      ...d,
      books: d.books.map(b =>
        b.id === bookId ? { ...b, quotes: b.quotes.filter(q => q.id !== quoteId) } : b
      )
    }))
  }, [])

  const toggleFavorite = useCallback((bookId, quoteId) => {
    setData(d => ({
      ...d,
      books: d.books.map(b =>
        b.id === bookId
          ? { ...b, quotes: b.quotes.map(q => q.id === quoteId ? { ...q, favorite: !q.favorite } : q) }
          : b
      )
    }))
  }, [])

  const togglePin = useCallback((bookId, quoteId) => {
    setData(d => ({
      ...d,
      books: d.books.map(b =>
        b.id === bookId
          ? { ...b, quotes: b.quotes.map(q => q.id === quoteId ? { ...q, pinned: !q.pinned } : q) }
          : b
      )
    }))
  }, [])

  // ── Stats ──────────────────────────────────────────────────────────────
  const stats = {
    totalBooks: books.length,
    totalQuotes: books.reduce((acc, b) => acc + (b.quotes?.length || 0), 0),
    totalFavorites: books.reduce((acc, b) => acc + (b.quotes?.filter(q => q.favorite)?.length || 0), 0),
  }

  return {
    books, stats,
    addBook, updateBook, deleteBook,
    addQuote, updateQuote, deleteQuote,
    toggleFavorite, togglePin,
    editMode, setEditMode,
    darkMode, setDarkMode,
  }
}
