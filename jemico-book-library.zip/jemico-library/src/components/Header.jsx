import React from 'react'
import { Moon, Sun, Edit3, Eye, Search } from 'lucide-react'

export default function Header({ darkMode, setDarkMode, editMode, setEditMode, searchQuery, setSearchQuery, stats }) {
  return (
    <header className="sticky top-0 z-30 border-b border-cream-200/80 dark:border-ink-700/60 bg-cream-100/80 dark:bg-ink-900/80 backdrop-blur-md">
      <div className="max-w-6xl mx-auto px-4 sm:px-6">
        <div className="flex items-center justify-between h-14 gap-4">
          {/* Brand */}
          <div className="flex-shrink-0">
            <h1 className="font-serif text-lg font-medium text-ink-800 dark:text-cream-100 tracking-tight">
              Jemico's Library
            </h1>
            <div className="hidden sm:flex items-center gap-3 text-xs text-ink-400 dark:text-ink-500 font-sans mt-0.5">
              <span>{stats.totalBooks} books</span>
              <span>·</span>
              <span>{stats.totalQuotes} quotes</span>
              <span>·</span>
              <span className="text-gold-500">{stats.totalFavorites} ♥</span>
            </div>
          </div>

          {/* Search */}
          <div className="flex-1 max-w-xs relative">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-ink-400 dark:text-ink-500" />
            <input
              className="input-field pl-9 py-1.5 text-sm"
              placeholder="Search quotes or books…"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
            />
          </div>

          {/* Controls */}
          <div className="flex items-center gap-1.5">
            <button
              onClick={() => setDarkMode(d => !d)}
              className="icon-btn"
              title={darkMode ? 'Light mode' : 'Dark mode'}
            >
              {darkMode ? <Sun size={15} /> : <Moon size={15} />}
            </button>
            <button
              onClick={() => setEditMode(e => !e)}
              className={`flex items-center gap-1.5 text-xs font-medium px-3 py-1.5 rounded-lg border transition-all
                ${editMode
                  ? 'bg-ink-800 dark:bg-cream-200 text-white dark:text-ink-900 border-transparent'
                  : 'border-cream-300 dark:border-ink-600 text-ink-500 dark:text-ink-400 hover:border-ink-400 dark:hover:border-ink-500'
                }`}
              title={editMode ? 'Switch to view mode' : 'Switch to edit mode'}
            >
              {editMode ? <><Edit3 size={12} /> Editing</> : <><Eye size={12} /> Viewing</>}
            </button>
          </div>
        </div>
      </div>
    </header>
  )
}
