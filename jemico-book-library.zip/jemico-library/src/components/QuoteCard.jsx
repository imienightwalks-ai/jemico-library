import React, { useState } from 'react'
import { Heart, Pin, Share2, Edit2, Trash2, Check, X } from 'lucide-react'
import { ImageQuoteCard } from './Lightbox'
import { formatDate, copyToClipboard } from '../utils/helpers'

export default function QuoteCard({
  quote, bookTitle, editMode,
  onEdit, onDelete, onFavorite, onPin,
  onImageClick,
}) {
  const [copied, setCopied] = useState(false)
  const [editing, setEditing] = useState(false)
  const [editText, setEditText] = useState(quote.text)
  const [editPage, setEditPage] = useState(quote.page || '')
  const [editTags, setEditTags] = useState((quote.tags || []).join(', '))

  function handleShare() {
    const text = quote.type === 'text'
      ? `"${quote.text}"\n— ${bookTitle}`
      : `Quote from "${bookTitle}"`
    copyToClipboard(text).then(() => {
      setCopied(true)
      setTimeout(() => setCopied(false), 1800)
    })
  }

  function handleSaveEdit() {
    const tags = editTags.split(',').map(t => t.trim()).filter(Boolean)
    onEdit({ text: editText, page: editPage, tags })
    setEditing(false)
  }

  const pinned = quote.pinned
  const fav = quote.favorite

  return (
    <div className={`glass-card p-5 animate-slide-up transition-all duration-200 hover:shadow-md
      ${pinned ? 'border-gold-400/40 dark:border-gold-500/30' : ''}
      ${fav ? 'border-l-2 border-l-gold-400' : ''}`}
    >
      {/* Pinned badge */}
      {pinned && (
        <div className="flex items-center gap-1 text-gold-500 text-xs font-medium mb-3">
          <Pin size={10} className="fill-gold-400" /> Pinned
        </div>
      )}

      {/* Content */}
      {editing ? (
        <div className="space-y-3">
          <textarea
            value={editText}
            onChange={e => setEditText(e.target.value)}
            className="input-field resize-none min-h-[80px] font-serif italic text-base"
            autoFocus
          />
          <input
            value={editPage}
            onChange={e => setEditPage(e.target.value)}
            placeholder="Page number (optional)"
            className="input-field text-sm"
          />
          <input
            value={editTags}
            onChange={e => setEditTags(e.target.value)}
            placeholder="Tags: love, life, wisdom (comma-separated)"
            className="input-field text-sm"
          />
          <div className="flex gap-2">
            <button onClick={handleSaveEdit} className="btn-primary flex items-center gap-1.5 text-xs py-2">
              <Check size={12} /> Save
            </button>
            <button onClick={() => setEditing(false)} className="btn-ghost flex items-center gap-1.5 text-xs py-2">
              <X size={12} /> Cancel
            </button>
          </div>
        </div>
      ) : (
        <>
          {quote.type === 'image' && quote.imageData ? (
            <ImageQuoteCard
              src={quote.imageData}
              alt={`Quote from ${bookTitle}`}
              onClick={() => onImageClick(quote.imageData)}
            />
          ) : (
            <blockquote className="font-serif text-base sm:text-lg italic leading-relaxed text-ink-700 dark:text-cream-200 mb-3">
              "{quote.text}"
            </blockquote>
          )}

          {/* Page */}
          {quote.page && (
            <p className="text-xs text-ink-400 dark:text-ink-500 font-sans mb-2">p. {quote.page}</p>
          )}

          {/* Tags */}
          {quote.tags?.length > 0 && (
            <div className="flex flex-wrap gap-1.5 mb-3">
              {quote.tags.map(tag => (
                <span key={tag} className="tag-pill">#{tag}</span>
              ))}
            </div>
          )}

          {/* Footer */}
          <div className="flex items-center justify-between mt-3 pt-3 border-t border-cream-200/80 dark:border-ink-700/60">
            <span className="text-xs text-ink-300 dark:text-ink-500 font-sans">{formatDate(quote.createdAt)}</span>
            <div className="flex items-center gap-0.5">
              {/* Favorite */}
              <button
                onClick={onFavorite}
                className={`icon-btn ${fav ? 'text-gold-400' : ''}`}
                title={fav ? 'Unfavorite' : 'Favorite'}
              >
                <Heart size={14} className={fav ? 'fill-gold-400' : ''} />
              </button>
              {/* Pin */}
              {editMode && (
                <button
                  onClick={onPin}
                  className={`icon-btn ${pinned ? 'text-gold-400' : ''}`}
                  title={pinned ? 'Unpin' : 'Pin'}
                >
                  <Pin size={14} className={pinned ? 'fill-gold-400' : ''} />
                </button>
              )}
              {/* Share */}
              <button onClick={handleShare} className="icon-btn" title="Copy to clipboard">
                {copied ? <Check size={14} className="text-green-500" /> : <Share2 size={14} />}
              </button>
              {/* Edit */}
              {editMode && quote.type === 'text' && (
                <button onClick={() => setEditing(true)} className="icon-btn" title="Edit">
                  <Edit2 size={14} />
                </button>
              )}
              {/* Delete */}
              {editMode && (
                <button onClick={onDelete} className="icon-btn hover:text-red-500" title="Delete">
                  <Trash2 size={14} />
                </button>
              )}
            </div>
          </div>
        </>
      )}
    </div>
  )
}
