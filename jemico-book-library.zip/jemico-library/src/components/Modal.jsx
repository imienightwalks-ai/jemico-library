import React, { useEffect } from 'react'
import { X } from 'lucide-react'

export default function Modal({ open, onClose, title, children, size = 'md' }) {
  useEffect(() => {
    if (!open) return
    const handler = e => { if (e.key === 'Escape') onClose() }
    window.addEventListener('keydown', handler)
    document.body.style.overflow = 'hidden'
    return () => {
      window.removeEventListener('keydown', handler)
      document.body.style.overflow = ''
    }
  }, [open, onClose])

  if (!open) return null

  const widths = { sm: 'max-w-sm', md: 'max-w-md', lg: 'max-w-lg', xl: 'max-w-xl' }

  return (
    <div
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-4"
      onClick={e => { if (e.target === e.currentTarget) onClose() }}
    >
      <div className="absolute inset-0 bg-ink-900/40 dark:bg-ink-900/70 backdrop-blur-sm animate-fade-in" />
      <div className={`relative w-full ${widths[size]} animate-scale-in`}>
        <div className="glass-card p-6 shadow-2xl border border-cream-200/80 dark:border-ink-600/60">
          <div className="flex items-center justify-between mb-5">
            <h2 className="font-serif text-xl text-ink-800 dark:text-cream-100 font-medium">{title}</h2>
            <button onClick={onClose} className="icon-btn">
              <X size={16} />
            </button>
          </div>
          {children}
        </div>
      </div>
    </div>
  )
}
