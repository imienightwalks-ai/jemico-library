# 📚 Jemico's Book Quotes Library

A premium personal digital library for storing book quotes — minimal, aesthetic, and smooth.

---

## ✨ Features

- **Book folders** — each book is its own section with a cover image
- **Text & Image quotes** — paste text or upload a screenshot
- **Favorites & Pins** — heart quotes you love, pin the most important ones
- **Tags** — categorize quotes with custom tags
- **Search** — search across all books and quotes instantly
- **Dark mode** — soft dark theme with one click
- **Edit / View mode** — share the link publicly; visitors see view-only mode
- **Local storage** — data persists automatically in the browser
- **Share button** — copy any quote to clipboard with one click
- **Stats** — total books, quotes, and favorites shown in the header
- **Responsive** — looks great on mobile, tablet, and desktop

---

## 🛠️ Run Locally

### Prerequisites
- Node.js 18+ installed ([download](https://nodejs.org))

### Steps

```bash
# 1. Navigate into the project folder
cd jemico-library

# 2. Install dependencies
npm install

# 3. Start the development server
npm run dev
```

Open [http://localhost:5173](http://localhost:5173) in your browser.

---

## 🚀 Deploy to Vercel (Recommended — Free)

### Option A: Vercel CLI
```bash
npm install -g vercel
vercel
```
Follow the prompts. Your site will be live at a `*.vercel.app` URL.

### Option B: Vercel Dashboard
1. Push your code to GitHub
2. Go to [vercel.com](https://vercel.com) → New Project
3. Import your GitHub repo
4. Vercel auto-detects Vite — click **Deploy**

Done! You'll get a public URL like `https://jemico-library.vercel.app`

---

## 🌐 Deploy to Netlify (Alternative — Free)

### Option A: Netlify CLI
```bash
npm install -g netlify-cli
npm run build
netlify deploy --prod --dir=dist
```

### Option B: Netlify Dashboard
1. Push to GitHub
2. Go to [app.netlify.com](https://app.netlify.com) → New site from Git
3. Connect repo → Build command: `npm run build`, Publish dir: `dist`
4. Click **Deploy**

---

## 🔒 Edit vs View Mode

- Toggle **Edit Mode** in the top-right corner
- In **Viewing** mode: visitors can browse quotes and favorites, but cannot add/edit/delete anything
- In **Editing** mode: full control to add books, upload covers, add/edit/delete quotes
- Share your public URL — others will see View mode by default

---

## 📁 Project Structure

```
src/
├── components/
│   ├── Header.jsx        # Top nav with search, dark mode, edit toggle
│   ├── BookCard.jsx      # Book grid tile
│   ├── BookView.jsx      # Inside a book — shows all quotes
│   ├── QuoteCard.jsx     # Individual quote card
│   ├── BookModal.jsx     # Add/edit book dialog
│   ├── AddQuoteModal.jsx # Add text or image quote
│   ├── Modal.jsx         # Reusable modal base
│   └── Lightbox.jsx      # Full-screen image viewer
├── hooks/
│   └── useStore.js       # All state + localStorage logic
├── utils/
│   └── helpers.js        # Date formatting, file utils
├── App.jsx               # Main app + routing logic
├── main.jsx              # Entry point
└── index.css             # Tailwind + custom styles
```

---

## 🎨 Tech Stack

- **React 18** — UI framework
- **Tailwind CSS 3** — utility-first styling
- **Vite** — fast build tool
- **Lucide React** — icons
- **LocalStorage** — data persistence (no backend needed)

---

*Made with care by Jemico* 📖
