import React, { useState, useEffect } from 'react'
import Modal from './Modal'
import { Upload, X } from 'lucide-react'
import { fileToDataUrl } from '../utils/helpers'

export default function BookModal({ open, onClose, onSave, initial }) {
  const [title, setTitle] = useState('')
  const [cover, setCover] = useState(null)

  useEffect(() => {
    if (open) {
      setTitle(initial?.title || '')
      setCover(initial?.cover || null)
    }
  }, [open, initial])

  async function handleFile(e) {
    const file = e.target.files?.[0]
    if (!file) return
    const data = await fileToDataUrl(file)
    setCover(data)
  }

  function handleSave() {
    if (!title.trim()) return
    onSave({ title: title.trim(), cover })
    onClose()
  }

  return (
    <Modal open={open} onClose={onClose} title={initial ? 'Edit Book' : 'Add New Book'}>
      <div className="space-y-4">
        <div>
          <label className="block text-xs font-medium text-ink-500 dark:text-ink-400 uppercase tracking-wide mb-1.5">
            Book Title *
          </label>
          <input
            className="input-field"
            placeholder="e.g. The Midnight Library"
            value={title}
            onChange={e => setTitle(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && handleSave()}
            autoFocus
          />
        </div>

        <div>
          <label className="block text-xs font-medium text-ink-500 dark:text-ink-400 uppercase tracking-wide mb-1.5">
            Cover Image (optional)
          </label>
          {cover ? (
            <div className="relative w-32 h-44 rounded-xl overflow-hidden border border-cream-300 dark:border-ink-600">
              <img src={cover} alt="Cover" className="w-full h-full object-cover" />
              <button
                onClick={() => setCover(null)}
                className="absolute top-1.5 right-1.5 w-6 h-6 bg-ink-900/70 text-white rounded-full flex items-center justify-center hover:bg-ink-900 transition-colors"
              >
                <X size={12} />
              </button>
            </div>
          ) : (
            <label className="flex flex-col items-center justify-center w-full h-28 border border-dashed border-cream-400 dark:border-ink-600 rounded-xl cursor-pointer hover:border-ink-400 dark:hover:border-ink-400 hover:bg-cream-50 dark:hover:bg-ink-800/50 transition-all group">
              <Upload size={18} className="text-ink-400 group-hover:text-ink-600 dark:group-hover:text-ink-300 transition-colors mb-2" />
              <span className="text-sm text-ink-400 dark:text-ink-500">Upload cover</span>
              <span className="text-xs text-ink-300 dark:text-ink-600 mt-0.5">JPG, PNG, WEBP</span>
              <input type="file" accept="image/*" className="hidden" onChange={handleFile} />
            </label>
          )}
        </div>

        <div className="flex gap-2 pt-1">
          <button onClick={handleSave} disabled={!title.trim()} className="btn-primary flex-1 disabled:opacity-40">
            {initial ? 'Save Changes' : 'Add Book'}
          </button>
          <button onClick={onClose} className="btn-ghost">Cancel</button>
        </div>
      </div>
    </Modal>
  )
}
