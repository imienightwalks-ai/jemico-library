/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  darkMode: 'class',
  theme: {
    extend: {
      fontFamily: {
        serif: ['"Cormorant Garamond"', 'Georgia', 'serif'],
        sans: ['"Jost"', 'system-ui', 'sans-serif'],
      },
      colors: {
        cream: {
          50:  '#fdfcf9',
          100: '#faf7f0',
          200: '#f4ede0',
          300: '#ecddd0',
          400: '#dfc9b3',
          500: '#c8a98a',
        },
        ink: {
          900: '#1a1612',
          800: '#2c2620',
          700: '#3d342c',
          600: '#5a4d42',
          500: '#7a6d62',
          400: '#9a8d82',
          300: '#b8aba0',
        },
        gold: {
          400: '#c9a84c',
          500: '#b8952e',
          600: '#9a7c1f',
        },
      },
      animation: {
        'fade-in': 'fadeIn 0.35s ease forwards',
        'scale-in': 'scaleIn 0.3s ease forwards',
        'slide-up': 'slideUp 0.35s ease forwards',
      },
      keyframes: {
        fadeIn: { from: { opacity: 0 }, to: { opacity: 1 } },
        scaleIn: { from: { opacity: 0, transform: 'scale(0.92)' }, to: { opacity: 1, transform: 'scale(1)' } },
        slideUp: { from: { opacity: 0, transform: 'translateY(14px)' }, to: { opacity: 1, transform: 'translateY(0)' } },
      },
      backdropBlur: { xs: '4px' },
    },
  },
  plugins: [],
}
